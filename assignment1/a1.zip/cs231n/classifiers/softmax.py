from builtins import range
import numpy as np
from random import shuffle
from past.builtins import xrange

def softmax_loss_naive(W, X, y, reg):
    """
    Softmax loss function, naive implementation (with loops)

    Inputs have dimension D, there are C classes, and we operate on minibatches
    of N examples.

    Inputs:
    - W: A numpy array of shape (D, C) containing weights.
    - X: A numpy array of shape (N, D) containing a minibatch of data.
    - y: A numpy array of shape (N,) containing training labels; y[i] = c means
      that X[i] has label c, where 0 <= c < C.
    - reg: (float) regularization strength

    Returns a tuple of:
    - loss as single float
    - gradient with respect to weights W; an array of same shape as W
    """
    # Initialize the loss and gradient to zero.
    loss = 0.0
    dW = np.zeros_like(W)

    #############################################################################
    # TODO: Compute the softmax loss and its gradient using explicit loops.     #
    # Store the loss in loss and the gradient in dW. If you are not careful     #
    # here, it is easy to run into numeric instability. Don't forget the        #
    # regularization!                                                           #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    
    # nb of examples
    N = X.shape[0]
    # nb of classes
    C = W.shape[1]
    
    # loop over the examples
    for i in range(N):
        # compute the logits
        z = np.dot(X[i,:], W)
        # for numerical stability
        z = z - np.max(z)
                
        # update the loss
        loss += -z[y[i]] + np.log(np.sum(np.exp(z)))
        
        for j in range(C):
            # update the gradient
            if j == y[i]:
                dW[:, j] += -X[i,:]
            dW[:, j] += 1/np.sum(np.exp(z)) * np.exp(z[j]) * X[i,:]
        
    # normalization
    loss /= N
    dW /= N

    # add the regularization term
    loss += reg * np.sum(W**2)
    dW += 2*reg * W
    
    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW


def softmax_loss_vectorized(W, X, y, reg):
    """
    Softmax loss function, vectorized version.

    Inputs and outputs are the same as softmax_loss_naive.
    """
    # Initialize the loss and gradient to zero.
    loss = 0.0
    dW = np.zeros_like(W)

    #############################################################################
    # TODO: Compute the softmax loss and its gradient using no explicit loops.  #
    # Store the loss in loss and the gradient in dW. If you are not careful     #
    # here, it is easy to run into numeric instability. Don't forget the        #
    # regularization!                                                           #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # nb of examples
    N = X.shape[0]
    C = W.shape[1]
    
    # compute the logits
    Z = np.dot(X, W)
    # for numerical stability
    Z = Z - np.max(Z, axis=1, keepdims=True)
    
    # compute the predictions
    exp_Z = np.exp(Z)
    Y_hat = exp_Z / np.sum(exp_Z, axis=1, keepdims = True)
    
    # convert labels to one-hot
    y_onehot = np.array([[j==y[i] for j in range(C)] for i in range(N)])
        
    # compute the loss
    loss = -np.mean(Z[np.arange(N), y]) + np.mean(np.log(np.sum(np.exp(Z), axis=1)))
    
    # compute the gradient
    #dW = 1/N * (-np.dot(X.T, y_onehot) + np.dot(X.T, 1/np.sum(np.exp(Z), axis=1, keepdims=True) * np.exp(Z)))
    dW = 1/N * np.dot(X.T, Y_hat - y_onehot)
    
    # add the regularization term
    loss += reg * np.sum(W**2)
    dW += 2*reg * W

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW
